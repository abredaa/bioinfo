## Usage 
this project is an implementation of Spectral forecast , 
Paul A. Gagniuc et al. Spectral forecast: A general purpose prediction model as an alternative to classical neural networks. Chaos 30, 033119 (2020); doi: 10.1063/1.5120818 (https://aip.scitation.org/doi/pdf/10.1063/1.5120818)

### Image
![Screenshot_2020-05-06 Screenshot](https://user-images.githubusercontent.com/40066763/81239792-767bfb00-900e-11ea-97f2-a9400fbc6abb.png)

implemented  by  Ahmad Nehme.


